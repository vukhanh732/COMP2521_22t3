
#include <assert.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>

#include "BSTree.h"

int leafCount(BSTree t, int pathLength) {
    // TODO

    return -1;
}

