
#include <assert.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>

#include "Graph.h"

void closeFollowers(Graph g, int src, int distance, int followers[]) {
    // TODO

}

