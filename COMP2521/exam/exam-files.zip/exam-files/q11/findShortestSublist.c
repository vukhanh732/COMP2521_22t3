
#include <assert.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>

#include "list.h"

List findShortestSublist(List l, int start, int end) {
    // TODO

    return ListNew();
}

